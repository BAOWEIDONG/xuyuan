/**
 * ============================================================================
 *  个人历程 - 过程数据计算引擎
 * ============================================================================
 *
 *  与结营报告（campReport.ts）的区别:
 *    结营报告关注"前后对比"（开营前 vs 结营后的指标变化）
 *    个人历程关注"过程中的数据"（每日打卡状态、体重趋势、运动累计、饮食得分趋势）
 *
 *  所有数据实时从打卡记录动态计算，学员每次打卡后数据自动更新。
 *
 *  前后端对接:
 *    后端可实现 GET /me/journey 返回 PersonalJourneyData
 *    计算逻辑应与本文件保持一致
 * ============================================================================
 */
import { format, addDays, differenceInCalendarDays, startOfWeek, endOfWeek, isWithinInterval, parseISO } from 'date-fns';
import type { DietRecord, ExerciseRecord, WeightRecord } from '../types';
import type { WeightTrend } from '../types';
import { isDayComplete, calculateStreak } from './streak';
import { calculateDietScore } from './scoring';
import { computeWeightTrend } from './campReport';

/** 每日打卡状态 */
export interface DailyCheckinStatus {
  date: string;           // yyyy-MM-dd
  isComplete: boolean;    // 三餐+运动+体重全部完成
  hasBreakfast: boolean;
  hasLunch: boolean;
  hasDinner: boolean;
  hasExercise: boolean;
  hasWeight: boolean;
  hasSnack: boolean;
  /** 完成项数 0-5（早餐+午餐+晚餐+运动+体重） */
  completionCount: number;
}

/** 每日饮食得分 */
export interface DailyDietScore {
  date: string;
  /** 每日封顶3分 */
  score: number;
  /** 当日餐次数 */
  meals: number;
}

/** 每周统计 */
export interface WeeklyStats {
  weekLabel: string;      // "第1周"
  weekStart: string;      // yyyy-MM-dd
  weekEnd: string;
  /** 完成全部打卡的天数 */
  completeDays: number;
  /** 该周天数（7或不足7） */
  totalDays: number;
  /** 完成率 */
  completionRate: number;
  /** 该周运动总时长 */
  exerciseDuration: number;
  /** 该周饮食得分 */
  dietScore: number;
}

/** 运动类型统计 */
export interface ExerciseTypeBreakdown {
  type: string;
  count: number;
  totalDuration: number;
  avgDuration: number;
}

/** 个人历程数据 */
export interface PersonalJourneyData {
  /** 每日打卡状态列表（从首条记录到今天） */
  dailyCheckins: DailyCheckinStatus[];
  /** 每日饮食得分列表 */
  dailyDietScores: DailyDietScore[];
  /** 每周统计列表 */
  weeklyStats: WeeklyStats[];
  /** 运动类型分布 */
  exerciseBreakdown: ExerciseTypeBreakdown[];
  /** 总运动时长（分钟） */
  totalExerciseDuration: number;
  /** 平均单次运动时长（分钟） */
  avgExerciseDuration: number;
  /** 最长连续打卡天数 */
  longestStreak: number;
  /** 当前连续打卡天数 */
  currentStreak: number;
  /** 总打卡天数 */
  totalCheckinDays: number;
  /** 完成全部打卡天数 */
  completeDays: number;
  /** 完成率 */
  completionRate: number;
  /** 体重趋势 */
  weightTrend: WeightTrend;
  /** 营期开始日期 */
  startDate: string | null;
  /** 营期天数（从首条记录到今天） */
  journeyDays: number;
}

/**
 * 计算每日打卡状态
 *
 * 从首条打卡记录的日期遍历到今天，逐天检查各项打卡情况。
 *
 * @param dietRecords     饮食记录
 * @param exerciseRecords 运动记录
 * @param weightRecords   体重记录
 * @param userId          学员ID（可选，用于多学员过滤）
 */
export function computeDailyCheckins(
  dietRecords: DietRecord[],
  exerciseRecords: ExerciseRecord[],
  weightRecords: WeightRecord[],
  userId?: string,
): DailyCheckinStatus[] {
  // 收集所有打卡日期
  const allDates = new Set<string>();
  dietRecords.forEach((r) => {
    if (!userId || !r.studentId || r.studentId === userId) allDates.add(r.date.substring(0, 10));
  });
  exerciseRecords.forEach((r) => {
    if (!userId || !r.studentId || r.studentId === userId) allDates.add(r.date.substring(0, 10));
  });
  weightRecords.forEach((r) => {
    if (!userId || !r.studentId || r.studentId === userId) allDates.add(r.date.substring(0, 10));
  });

  if (allDates.size === 0) return [];

  const sortedDates = Array.from(allDates).sort();
  const startDate = sortedDates[0];
  const todayStr = format(new Date(), 'yyyy-MM-dd');

  // 从首条记录到今天，逐天生成状态
  const result: DailyCheckinStatus[] = [];
  let cursor = new Date(startDate);
  const end = new Date(todayStr);

  while (cursor <= end) {
    const dateStr = format(cursor, 'yyyy-MM-dd');

    const dayDiets = dietRecords.filter((r) =>
      r.date.startsWith(dateStr) && (!userId || !r.studentId || r.studentId === userId),
    );
    const dayExercises = exerciseRecords.filter((r) =>
      r.date.startsWith(dateStr) && (!userId || !r.studentId || r.studentId === userId),
    );
    const dayWeights = weightRecords.filter((r) =>
      r.date.startsWith(dateStr) && (!userId || !r.studentId || r.studentId === userId),
    );

    const hasBreakfast = dayDiets.some((r) => r.meal === 'breakfast');
    const hasLunch = dayDiets.some((r) => r.meal === 'lunch');
    const hasDinner = dayDiets.some((r) => r.meal === 'dinner');
    const hasExercise = dayExercises.length > 0;
    const hasWeight = dayWeights.length > 0;
    const hasSnack = dayDiets.some((r) => r.meal === 'snack');

    const completionCount = [hasBreakfast, hasLunch, hasDinner, hasExercise, hasWeight].filter(Boolean).length;

    result.push({
      date: dateStr,
      isComplete: isDayComplete(dateStr, exerciseRecords, dietRecords, weightRecords, userId),
      hasBreakfast,
      hasLunch,
      hasDinner,
      hasExercise,
      hasWeight,
      hasSnack,
      completionCount,
    });

    cursor = addDays(cursor, 1);
  }

  return result;
}

/**
 * 计算每日饮食得分趋势
 *
 * 按日聚合饮食记录，每日得分 = min(Σ dietitianScore, 3)。
 * 未批注记录(dietitianScore=null/undefined)计 0 分，须营养师点评后才计分。
 * 仅返回有饮食记录的日期。
 *
 * @param dietRecords 饮食记录
 * @param userId      学员ID
 */
export function computeDailyDietScores(
  dietRecords: DietRecord[],
  userId?: string,
): DailyDietScore[] {
  const dayMap: Record<string, DietRecord[]> = {};

  dietRecords.forEach((r) => {
    if (userId && r.studentId && r.studentId !== userId) return;
    const day = r.date.substring(0, 10);
    if (!dayMap[day]) dayMap[day] = [];
    dayMap[day].push(r);
  });

  return Object.keys(dayMap)
    .sort()
    .map((date) => {
      const records = dayMap[date];
      const rawScore = records.reduce((sum, r) => sum + (r.dietitianScore != null ? r.dietitianScore : 0), 0);
      return {
        date,
        score: Math.min(rawScore, 3),
        meals: records.length,
      };
    });
}

/**
 * 计算每周打卡统计
 *
 * 从首条打卡记录开始，按自然周（周一~周日）分组统计。
 *
 * @param dietRecords     饮食记录
 * @param exerciseRecords 运动记录
 * @param userId          学员ID
 */
export function computeWeeklyStats(
  dietRecords: DietRecord[],
  exerciseRecords: ExerciseRecord[],
  weightRecords: WeightRecord[],
  userId?: string,
): WeeklyStats[] {
  // 收集所有打卡日期确定起始点
  const allDates = new Set<string>();
  dietRecords.forEach((r) => {
    if (!userId || !r.studentId || r.studentId === userId) allDates.add(r.date.substring(0, 10));
  });
  exerciseRecords.forEach((r) => {
    if (!userId || !r.studentId || r.studentId === userId) allDates.add(r.date.substring(0, 10));
  });

  if (allDates.size === 0) return [];

  const sortedDates = Array.from(allDates).sort();
  const startDate = new Date(sortedDates[0]);
  const today = new Date();

  // 按自然周分组
  const weeks: WeeklyStats[] = [];
  let weekStart = startOfWeek(startDate, { weekStartsOn: 1 });
  let weekIndex = 1;

  while (weekStart <= today) {
    const weekEnd = endOfWeek(weekStart, { weekStartsOn: 1 });
    const actualEnd = weekEnd > today ? today : weekEnd;

    // 统计这一周内的打卡情况
    let completeDays = 0;
    const daysInWeek = differenceInCalendarDays(actualEnd, weekStart) + 1;
    let exerciseDuration = 0;
    let weekDietRecords: DietRecord[] = [];

    let cursor = new Date(weekStart);
    while (cursor <= actualEnd) {
      const dateStr = format(cursor, 'yyyy-MM-dd');

      // 完成天数：三餐+运动+体重全部完成
      if (isDayComplete(dateStr, exerciseRecords, dietRecords, weightRecords, userId)) {
        completeDays++;
      }

      // 运动时长
      exerciseRecords.forEach((r) => {
        if (r.date.startsWith(dateStr) && (!userId || !r.studentId || r.studentId === userId)) {
          exerciseDuration += r.duration;
        }
      });

      // 饮食记录
      weekDietRecords = weekDietRecords.concat(
        dietRecords.filter((r) => r.date.startsWith(dateStr) && (!userId || !r.studentId || r.studentId === userId)),
      );

      cursor = addDays(cursor, 1);
    }

    const dietScore = calculateDietScore(weekDietRecords);

    weeks.push({
      weekLabel: `第${weekIndex}周`,
      weekStart: format(weekStart, 'yyyy-MM-dd'),
      weekEnd: format(actualEnd, 'yyyy-MM-dd'),
      completeDays,
      totalDays: daysInWeek,
      completionRate: daysInWeek > 0 ? completeDays / daysInWeek : 0,
      exerciseDuration,
      dietScore,
    });

    weekStart = addDays(weekEnd, 1);
    weekIndex++;
  }

  return weeks;
}

/**
 * 计算运动类型分布
 *
 * @param exerciseRecords 运动记录
 * @param userId          学员ID
 */
export function computeExerciseBreakdown(
  exerciseRecords: ExerciseRecord[],
  userId?: string,
): ExerciseTypeBreakdown[] {
  const filtered = userId
    ? exerciseRecords.filter((r) => r.studentId === userId || !r.studentId)
    : exerciseRecords;

  const typeMap: Record<string, { count: number; totalDuration: number }> = {};

  filtered.forEach((r) => {
    const type = r.type || '其他';
    if (!typeMap[type]) typeMap[type] = { count: 0, totalDuration: 0 };
    typeMap[type].count++;
    typeMap[type].totalDuration += r.duration;
  });

  return Object.entries(typeMap)
    .map(([type, data]) => ({
      type,
      count: data.count,
      totalDuration: data.totalDuration,
      avgDuration: data.count > 0 ? data.totalDuration / data.count : 0,
    }))
    .sort((a, b) => b.totalDuration - a.totalDuration);
}

/**
 * 生成个人历程数据
 *
 * 这是个人历程页面的唯一入口函数。
 * 传入原始打卡记录，返回完整的 PersonalJourneyData。
 * 所有数据实时计算，随打卡数据动态变更。
 *
 * @param dietRecords     学员的饮食记录
 * @param exerciseRecords 学员的运动记录
 * @param weightRecords   学员的体重记录
 * @param userId          学员ID
 */
export function generatePersonalJourney(
  dietRecords: DietRecord[],
  exerciseRecords: ExerciseRecord[],
  weightRecords: WeightRecord[],
  userId?: string,
): PersonalJourneyData {
  // 1. 每日打卡状态
  const dailyCheckins = computeDailyCheckins(dietRecords, exerciseRecords, weightRecords, userId);

  // 2. 每日饮食得分
  const dailyDietScores = computeDailyDietScores(dietRecords, userId);

  // 3. 每周统计
  const weeklyStats = computeWeeklyStats(dietRecords, exerciseRecords, weightRecords, userId);

  // 4. 运动类型分布
  const exerciseBreakdown = computeExerciseBreakdown(exerciseRecords, userId);

  // 5. 体重趋势
  const weightTrend = computeWeightTrend(weightRecords);

  // 6. 连续打卡
  const streakResult = calculateStreak(exerciseRecords, dietRecords, weightRecords, userId);

  // 7. 最长连续（从 dailyCheckins 计算）
  let longestStreak = 0;
  let currentRun = 0;
  let prevDate: string | null = null;
  for (const d of dailyCheckins) {
    if (d.isComplete) {
      if (prevDate && differenceInCalendarDays(new Date(d.date), new Date(prevDate)) === 1) {
        currentRun++;
      } else {
        currentRun = 1;
      }
      longestStreak = Math.max(longestStreak, currentRun);
    } else {
      currentRun = 0;
    }
    prevDate = d.date;
  }

  // 8. 汇总
  const totalCheckinDays = dailyCheckins.filter((d) =>
    d.hasBreakfast || d.hasLunch || d.hasDinner || d.hasExercise || d.hasWeight,
  ).length;
  const completeDays = dailyCheckins.filter((d) => d.isComplete).length;
  const totalExerciseDuration = exerciseBreakdown.reduce((sum, e) => sum + e.totalDuration, 0);
  const exerciseCount = exerciseBreakdown.reduce((sum, e) => sum + e.count, 0);

  const startDate = dailyCheckins.length > 0 ? dailyCheckins[0].date : null;
  const journeyDays = dailyCheckins.length;

  return {
    dailyCheckins,
    dailyDietScores,
    weeklyStats,
    exerciseBreakdown,
    totalExerciseDuration,
    avgExerciseDuration: exerciseCount > 0 ? totalExerciseDuration / exerciseCount : 0,
    longestStreak: Math.max(longestStreak, streakResult.currentStreak),
    currentStreak: streakResult.currentStreak,
    totalCheckinDays,
    completeDays,
    completionRate: journeyDays > 0 ? completeDays / journeyDays : 0,
    weightTrend,
    startDate,
    journeyDays,
  };
}
