<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { format } from 'date-fns';
import { useAppStore } from '../store/app';
import { MOCK_STUDENTS } from '../mock/data';
import { NavBar, Card } from './ui';
import { Activity, Coffee, Calendar, FileText, UserCircle, Scale, PlayCircle, LogOut, Medal, Target, Trophy, Gift, Flame, BookOpen, Check, MessageCircle, ChevronRight } from 'lucide-vue-next';
import { Tabbar as VanTabbar, TabbarItem as VanTabbarItem } from 'vant';
import { rankStudents } from '../lib/scoring';
import { getTodayQuote } from '../lib/motivationalQuotes';
import { calculateStreak } from '../lib/streak';

const store = useAppStore();

const todayStr = format(new Date(), 'yyyy-MM-dd');
const isMine = (r: { studentId?: string }) => r.studentId === store.user?.id || !r.studentId;

const latestWeight = computed(() => {
  const myRecords = store.weightRecords
    .filter(isMine)
    .sort((a, b) => b.date.localeCompare(a.date));
  return myRecords.length > 0 ? myRecords[0].weight : store.user?.weight || '--';
});

const scoreData = computed(() => {
  if (!store.user) return null;
  const ranked = rankStudents(MOCK_STUDENTS, store.dietRecords, store.exerciseRecords);
  return ranked.find((s) => s.studentId === store.user!.id) || null;
});

// 与前一名（更高分者）的分差
const gapToAhead = computed(() => {
  if (!store.user) return null;
  const ranked = rankStudents(MOCK_STUDENTS, store.dietRecords, store.exerciseRecords);
  const me = ranked.find((s) => s.studentId === store.user!.id);
  if (!me || me.rank <= 1) return null;
  // 找到刚好比我分高的最近一位
  const ahead = ranked
    .filter((s) => s.totalScore > me.totalScore)
    .sort((a, b) => a.totalScore - b.totalScore)[0];
  if (!ahead) return null;
  return ahead.totalScore - me.totalScore;
});

const todayQuote = getTodayQuote();

const streakData = computed(() => calculateStreak(store.exerciseRecords, store.dietRecords, store.weightRecords, store.user?.id));
const currentStreak = computed(() => streakData.value.currentStreak);

// ---- 今日打卡状态 ----
const todayExerciseDone = computed(() => store.exerciseRecords.some((r) => isMine(r) && r.date.startsWith(todayStr)));
const todayWeightDone = computed(() => store.weightRecords.some((r) => isMine(r) && r.date.startsWith(todayStr)));
const todayDietMeals = computed(() => {
  const meals = new Set(store.dietRecords.filter((r) => isMine(r) && r.date.startsWith(todayStr)).map((r) => r.meal));
  return meals;
});
const todayDietDone = computed(() => todayDietMeals.value.size > 0);
const todayDietLabel = computed(() => {
  const count = todayDietMeals.value.size;
  if (count === 0) return '拍照上传';
  if (count >= 3) return '已完成 ✓';
  return `已记 ${count} 餐`;
});

// ---- 营养师未读批注 ----
const unreadComments = computed(() => {
  const diet = store.dietRecords.filter((r) => isMine(r) && r.dietitianComment && !r.commentRead);
  const exercise = store.exerciseRecords.filter((r) => isMine(r) && r.dietitianComment && !r.commentRead);
  const weight = store.weightRecords.filter((r) => isMine(r) && r.dietitianComment && !r.commentRead);
  return [
    ...diet.map((r) => ({ ...r, _type: 'diet' as const })),
    ...exercise.map((r) => ({ ...r, _type: 'exercise' as const })),
    ...weight.map((r) => ({ ...r, _type: 'weight' as const })),
  ].sort((a, b) => (b.dietitianCommentDate || '').localeCompare(a.dietitianCommentDate || ''));
});
const latestUnread = computed(() => unreadComments.value[0] || null);
const latestUnreadView = computed(() => {
  if (!latestUnread.value) return 'diet';
  return latestUnread.value._type === 'diet' ? 'diet' : latestUnread.value._type === 'exercise' ? 'exercise' : 'weight-checkin';
});

// 卡片入场动画
const visibleCards = ref<number[]>([]);
onMounted(() => {
  const delays = [0, 100, 200, 300, 400, 500, 600, 700, 800, 900];
  delays.forEach((delay, idx) => {
    setTimeout(() => visibleCards.value.push(idx), delay);
  });
});
</script>

<template>
  <div class="flex min-h-full flex-col bg-[#F4F6F8] pb-28 font-sans relative">
    <!-- Dynamic Background Header -->
    <div class="relative pt-[calc(env(safe-area-inset-top)+2.5rem)] px-6 pb-8 bg-gradient-to-br from-[#07C160] via-[#06b558] to-[#03a14f] rounded-b-[32px] shadow-[0_10px_34px_-14px_rgba(7,193,96,0.5)] overflow-hidden">
      <div class="absolute -top-12 -right-12 w-64 h-64 bg-white/15 rounded-full blur-3xl pointer-events-none animate-pulse"></div>
      <div class="absolute -bottom-16 -left-10 w-56 h-56 bg-white/10 rounded-full blur-3xl pointer-events-none animate-pulse" style="animation-delay: 1s;"></div>

      <div class="relative z-10 flex justify-between items-center mb-6">
        <h1 class="text-sm font-bold text-white flex items-center gap-1.5 px-3 py-1.5 bg-white/15 rounded-full backdrop-blur-md shrink-0">
          <Medal class="h-4 w-4 text-amber-300 shrink-0" />
          <span class="truncate">28天营养减重训练营</span>
        </h1>
        <button @click="store.setCurrentView('login')" class="text-white/95 hover:text-white transition-colors flex items-center gap-1 text-xs bg-white/15 px-3 py-1.5 rounded-full backdrop-blur-md shrink-0 ml-2">
          <LogOut class="h-3 w-3 shrink-0" /> 退出
        </button>
      </div>

      <div class="relative z-10 flex items-start space-x-4">
        <div class="h-16 w-16 rounded-full bg-white/95 p-1 shadow-lg shrink-0 animate-pop-in">
          <div class="h-full w-full bg-gray-100 rounded-full flex items-center justify-center overflow-hidden">
            <UserCircle class="h-12 w-12 text-gray-400 shrink-0" />
          </div>
        </div>
        <div class="flex-1 min-w-0">
          <h2 class="text-2xl font-black text-white tracking-tight truncate animate-pop-in" style="animation-delay: 0.1s;">你好，{{ store.user?.name || '学员' }}</h2>
          <div class="flex items-start gap-2 mt-2 animate-pop-in" style="animation-delay: 0.2s;">
            <span class="text-[11px] font-bold text-[#07C160] bg-white px-2 py-0.5 rounded-full tracking-wide shrink-0 mt-0.5">DAY {{ currentStreak }}</span>
            <span class="text-xs text-white/95 font-medium tracking-wide leading-snug min-h-[36px] break-words break-all">{{ todayQuote }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="flex-1 px-5 pt-5 space-y-5 relative z-20">
      <!-- 营养师未读批注提醒 -->
      <div
        v-if="latestUnread"
        @click="store.setCurrentView(latestUnreadView as any)"
        class="bg-gradient-to-r from-[#07C160] to-[#06b558] rounded-2xl p-4 flex items-center gap-3 shadow-lg shadow-[#07C160]/20 cursor-pointer hover:shadow-xl transition-all animate-pop-in"
      >
        <div class="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0 relative">
          <MessageCircle class="w-5 h-5 text-white" />
          <span class="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-[9px] font-bold flex items-center justify-center">{{ unreadComments.length }}</span>
        </div>
        <div class="flex-1 min-w-0">
          <div class="text-xs text-white/80 font-medium mb-0.5">{{ latestUnread.dietitianName || '营养师' }} 回复了你</div>
          <div class="text-sm text-white font-medium truncate">{{ latestUnread.dietitianComment }}</div>
        </div>
        <ChevronRight class="w-4 h-4 text-white/70 shrink-0" />
      </div>

      <!-- Streak banner -->
      <div :class="['bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-100 rounded-2xl p-4 flex items-center gap-3 shadow-sm card-enter cursor-pointer hover:shadow-md transition-all', visibleCards.includes(0) ? 'card-enter-active' : '']" @click="store.setCurrentView('calendar')">
        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-yellow-400 flex items-center justify-center text-white shadow-lg animate-pulse">
          <Flame class="w-6 h-6" />
        </div>
        <div class="flex-1">
          <div class="text-xs text-orange-600 font-bold mb-0.5">连续打卡</div>
          <div class="text-2xl font-black text-gray-900">{{ currentStreak }} 天</div>
        </div>
        <div class="text-right">
          <div class="text-[10px] text-gray-500 mb-1">累计打卡</div>
          <div class="text-lg font-bold text-gray-700">{{ streakData.totalDays }} 天</div>
        </div>
        <Calendar class="w-4 h-4 text-orange-300 shrink-0" />
      </div>

      <div class="grid grid-cols-2 gap-4 items-stretch">
        <Card :class="['flex flex-col justify-center p-5 cursor-pointer hover:shadow-lg transition-all border-0 shadow-[0_4px_20px_-8px_rgba(15,23,42,0.14)] relative overflow-hidden h-full card-enter', visibleCards.includes(1) ? 'card-enter-active' : '']" @click="store.setCurrentView('weight-checkin')">
          <div class="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#07C160]/20 to-teal-100 rounded-full blur-2xl transform translate-x-1/4 -translate-y-1/4 z-0 pointer-events-none"></div>
          <div class="relative z-10">
            <div class="flex items-center gap-1 mb-2">
              <Target class="w-4 h-4 text-[#07C160] shrink-0" />
              <div class="text-xs text-gray-500 font-bold truncate">最新体重</div>
            </div>
            <div class="flex items-end gap-1">
              <span class="text-3xl font-black text-gray-900 tracking-tighter truncate">{{ latestWeight }}</span>
              <span class="text-sm mb-1 text-gray-500 font-medium shrink-0">kg</span>
            </div>
          </div>
        </Card>

        <Card :class="['flex flex-col justify-center p-5 cursor-pointer hover:shadow-lg transition-all border-0 shadow-[0_4px_20px_-8px_rgba(15,23,42,0.14)] relative overflow-hidden h-full card-enter', visibleCards.includes(2) ? 'card-enter-active' : '']" @click="store.setCurrentView('ranking')">
          <div class="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#FF976A]/20 to-orange-100 rounded-full blur-2xl transform translate-x-1/4 -translate-y-1/4 z-0 pointer-events-none"></div>
          <div class="relative z-10 flex flex-col h-full justify-between">
            <div>
              <div class="flex items-center gap-1 mb-2">
                <Trophy class="w-4 h-4 text-[#FF976A] shrink-0" />
                <div class="text-xs text-gray-500 font-bold truncate">我的排名</div>
              </div>
              <div class="flex items-end gap-1">
                <span class="text-[28px] font-black text-gray-900 tracking-tighter truncate">第{{ scoreData?.rank || '--' }}位</span>
              </div>
            </div>
            <div class="text-xs text-gray-500 font-medium mt-1 truncate">总计 {{ scoreData?.totalScore || 0 }} 分</div>
            <div v-if="gapToAhead !== null" class="text-[10px] text-[#FF976A] font-bold mt-0.5">距前一名还差 {{ gapToAhead }} 分</div>
            <div v-else-if="scoreData?.rank === 1" class="text-[10px] text-yellow-500 font-bold mt-0.5">👑 你是第一名！</div>
          </div>
        </Card>
      </div>

      <div>
        <h3 class="text-sm font-bold text-gray-900 mb-3 ml-1 flex items-center gap-1.5">
          <div class="w-1.5 h-4 bg-[#07C160] rounded-full"></div>
          每日打卡任务
        </h3>
        <div class="grid grid-cols-3 gap-3">
          <!-- 运动 -->
          <Card :class="['flex flex-col items-center justify-center py-6 cursor-pointer transition-all border-0 shadow-sm card-enter relative', visibleCards.includes(3) ? 'card-enter-active' : '', todayExerciseDone ? 'opacity-90' : 'hover:ring-2 ring-[#07C160]']" @click="store.setCurrentView('exercise')">
            <div v-if="todayExerciseDone" class="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#07C160] flex items-center justify-center">
              <Check class="w-3 h-3 text-white" />
            </div>
            <div :class="['w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-sm transition-transform hover:scale-110', todayExerciseDone ? 'bg-gray-300' : 'bg-gradient-to-br from-[#07C160] to-green-500 animate-pulse']">
              <Activity class="h-6 w-6" />
            </div>
            <div class="text-sm font-bold text-gray-900 mb-0.5">运动打卡</div>
            <div :class="['text-[10px]', todayExerciseDone ? 'text-[#07C160] font-bold' : 'text-gray-400']">{{ todayExerciseDone ? '已完成 ✓' : '记录消耗' }}</div>
          </Card>

          <!-- 饮食 -->
          <Card :class="['flex flex-col items-center justify-center py-6 cursor-pointer transition-all border-0 shadow-sm card-enter relative', visibleCards.includes(4) ? 'card-enter-active' : '', todayDietDone ? 'opacity-90' : 'hover:ring-2 ring-[#FF976A]']" @click="store.setCurrentView('diet')">
            <div v-if="todayDietDone" class="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#07C160] flex items-center justify-center">
              <Check class="w-3 h-3 text-white" />
            </div>
            <div :class="['w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-sm transition-transform hover:scale-110', todayDietDone ? 'bg-gray-300' : 'bg-gradient-to-br from-[#FF976A] to-orange-400 animate-pulse']">
              <Coffee class="h-6 w-6" />
            </div>
            <div class="text-sm font-bold text-gray-900 mb-0.5">饮食打卡</div>
            <div :class="['text-[10px]', todayDietDone ? 'text-[#07C160] font-bold' : 'text-gray-400']">{{ todayDietLabel }}</div>
          </Card>

          <!-- 体重 -->
          <Card :class="['flex flex-col items-center justify-center py-6 cursor-pointer transition-all border-0 shadow-sm card-enter relative', visibleCards.includes(5) ? 'card-enter-active' : '', todayWeightDone ? 'opacity-90' : 'hover:ring-2 ring-[#1677FF]']" @click="store.setCurrentView('weight-checkin')">
            <div v-if="todayWeightDone" class="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#07C160] flex items-center justify-center">
              <Check class="w-3 h-3 text-white" />
            </div>
            <div :class="['w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-sm transition-transform hover:scale-110', todayWeightDone ? 'bg-gray-300' : 'bg-gradient-to-br from-[#1677FF] to-blue-500 animate-pulse']">
              <Scale class="h-6 w-6" />
            </div>
            <div class="text-sm font-bold text-gray-900 mb-0.5">体重打卡</div>
            <div :class="['text-[10px]', todayWeightDone ? 'text-[#07C160] font-bold' : 'text-gray-400']">{{ todayWeightDone ? '已完成 ✓' : '见证蜕变' }}</div>
          </Card>
        </div>
      </div>

      <div>
        <h3 class="text-sm font-bold text-gray-900 mb-3 ml-1 flex items-center gap-1.5 mt-2">
          <div class="w-1.5 h-4 bg-[#04a551] rounded-full"></div>
          营期回顾与指导
        </h3>
        <div class="grid grid-cols-2 gap-3">
          <Card :class="['p-5 cursor-pointer hover:shadow-md transition-all border-0 shadow-sm flex flex-col justify-between h-32 bg-white card-enter', visibleCards.includes(6) ? 'card-enter-active' : '']" @click="store.setCurrentView('calendar')">
            <div class="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-orange-500 mb-2">
              <Calendar class="h-5 w-5" />
            </div>
            <div>
              <div class="text-sm font-bold text-gray-900">打卡日历</div>
              <div class="text-[11px] text-gray-500 mt-0.5">查看历史记录</div>
            </div>
          </Card>

          <Card :class="['p-5 cursor-pointer hover:shadow-md transition-all border-0 shadow-sm flex flex-col justify-between h-32 bg-white card-enter', visibleCards.includes(7) ? 'card-enter-active' : '']" @click="store.setCurrentView('activities-list')">
            <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-500 mb-2">
              <PlayCircle class="h-5 w-5" />
            </div>
            <div>
              <div class="text-sm font-bold text-gray-900">锻炼活动</div>
              <div class="text-[11px] text-gray-500 mt-0.5">健康指导与教学</div>
            </div>
          </Card>

          <Card :class="['p-5 cursor-pointer hover:shadow-md transition-all border border-orange-100 flex flex-col justify-between h-32 bg-gradient-to-br from-orange-50 to-yellow-50 card-enter', visibleCards.includes(8) ? 'card-enter-active' : '']" @click="store.setCurrentView('reward')">
            <div class="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center text-orange-500 mb-2 animate-pulse">
              <Gift class="h-5 w-5" />
            </div>
            <div>
              <div class="text-sm font-bold text-gray-900">打卡奖励</div>
              <div class="text-[11px] text-gray-500 mt-0.5">坚持打卡领礼品</div>
            </div>
          </Card>

          <Card :class="['p-5 cursor-pointer hover:shadow-md transition-all border-0 shadow-sm flex flex-col justify-between h-32 bg-gradient-to-br from-[#07C160]/5 to-teal-50 card-enter', visibleCards.includes(9) ? 'card-enter-active' : '']" @click="store.setCurrentView('personal-journey')">
            <div class="w-10 h-10 rounded-xl bg-[#07C160]/10 flex items-center justify-center text-[#07C160] mb-2">
              <BookOpen class="h-5 w-5" />
            </div>
            <div>
              <div class="text-sm font-bold text-gray-900">个人历程</div>
              <div class="text-[11px] text-gray-500 mt-0.5">我的报告与成就</div>
            </div>
          </Card>
        </div>
      </div>
    </div>

    <!-- Bottom Nav (Vant Tabbar) -->
    <VanTabbar class="custom-tabbar" :model-value="0">
      <VanTabbarItem>
        <template #icon><Activity class="h-6 w-6" /></template>
        首页
      </VanTabbarItem>
      <VanTabbarItem @click="store.setCurrentView('health-profile')">
        <template #icon><FileText class="h-6 w-6" /></template>
        档案
      </VanTabbarItem>
    </VanTabbar>
  </div>
</template>

<style scoped>
@keyframes popIn {
  0% { transform: scale(0.8); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}
.animate-pop-in {
  animation: popIn 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}
.card-enter {
  opacity: 0;
  transform: translateY(20px);
  transition: opacity 0.4s ease-out, transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.card-enter-active {
  opacity: 1;
  transform: translateY(0);
}
</style>
