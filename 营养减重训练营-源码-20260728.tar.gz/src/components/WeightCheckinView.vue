<script setup lang="ts">
import { ref, watch, computed, onMounted } from 'vue';
import { format } from 'date-fns';
import { useAppStore } from '../store/app';
import { celebrateCheckin, celebrateReward } from '../lib/confetti';
import { calculateStreak } from '../lib/streak';
import { uploadFile } from '../lib/api';
import { NavBar, Button, Card } from './ui';
import { Scale, TrendingUp, TrendingDown, Minus, Camera, X, ChevronDown, Target, Pencil } from 'lucide-vue-next';
import { formatDateTime } from '../lib/utils';
import { useDateGrouping } from '../composables/useDateGrouping';

const store = useAppStore();
const weight = ref('');
const error = ref('');
const photos = ref<string[]>([]);
const photoInputRef = ref<HTMLInputElement | null>(null);

// 照片上传区折叠（默认收起，减少视觉干扰）
const showPhotoUpload = ref(false);

// 目标体重
const targetWeight = ref(store.user?.targetWeight ? String(store.user.targetWeight) : '');
const editingTarget = ref(false);
const saveTarget = () => {
  const v = parseFloat(targetWeight.value);
  if (!isNaN(v) && v > 20 && v < 300 && store.user) {
    store.setUser({ ...store.user, targetWeight: parseFloat(v.toFixed(1)) });
  } else if (targetWeight.value === '' && store.user) {
    const u = { ...store.user };
    delete u.targetWeight;
    store.setUser(u);
  }
  editingTarget.value = false;
};

// 学员对批注的反馈
const markWeightFeedback = (recordId: string, feedback: 'received' | 'helpful') => {
  store.updateWeightRecord(recordId, { studentFeedback: feedback, commentRead: true });
};

const handlePhotoSelect = async (e: Event) => {
  const files = Array.from((e.target as HTMLInputElement).files || []) as File[];
  if (files.length === 0) return;
  const remaining = 6 - photos.value.length;
  const urls = await Promise.all(files.slice(0, remaining).map((f) => uploadFile(f)));
  photos.value = [...photos.value, ...urls];
  (e.target as HTMLInputElement).value = '';
};

const removePhoto = (index: number) => {
  photos.value = photos.value.filter((_, i) => i !== index);
};

watch(
  [() => store.weightRecords, () => store.user],
  () => {
    const myRecords = store.weightRecords.filter((r) => r.studentId === store.user?.id || !r.studentId);
    if (myRecords.length > 0) {
      const latest = [...myRecords].sort((a, b) => b.date.localeCompare(a.date))[0];
      weight.value = latest.weight.toString();
    } else if (store.user?.weight) {
      weight.value = store.user.weight.toString();
    }
  },
  { immediate: true },
);

const handleSubmit = () => {
  const val = parseFloat(weight.value);
  if (isNaN(val) || val <= 0 || val > 300) {
    error.value = '请输入合理的体重数值（例如: 65.5）';
    return;
  }

  error.value = '';
  store.addWeightRecord({
    id: `w_${Date.now()}`,
    studentId: store.user?.id || 's1',
    date: format(new Date(), 'yyyy-MM-dd HH:mm'),
    weight: parseFloat(val.toFixed(1)),
    photos: photos.value.length > 0 ? photos.value : undefined,
  });

  // Check reward
  const streakResult = calculateStreak(store.exerciseRecords, store.dietRecords, store.weightRecords, store.user?.id);
  const matchedTier = store.rewardTiers.find(t => t.requiredDays === streakResult.currentStreak);
  if (matchedTier) { celebrateReward(matchedTier.name); } else { celebrateCheckin('weight'); }

  // Stay on page
  weight.value = '';
  photos.value = [];
};

// ---- Weight trend chart ----
const sortedRecords = computed(() =>
  [...store.weightRecords]
    .filter((r) => r.studentId === store.user?.id || !r.studentId)
    .sort((a, b) => a.date.localeCompare(b.date))
);

// 按日期分组的历史记录
const reversedRecords = computed(() => [...sortedRecords.value].reverse());
const { grouped: groupedHistory, toggleDate, isExpanded } = useDateGrouping(reversedRecords);

const weightStats = computed(() => {
  const recs = sortedRecords.value;
  if (recs.length === 0) return null;
  const weights = recs.map(r => r.weight);
  const first = weights[0];
  const last = weights[weights.length - 1];
  const change = parseFloat((last - first).toFixed(1));
  return {
    first, last, change,
    min: Math.min(...weights),
    max: Math.max(...weights),
    count: weights.length,
  };
});

// Chart geometry
const CW = 320, CH = 180;
const PL = 36, PR = 14, PT = 14, PB = 26;
const PW = CW - PL - PR;
const PH = CH - PT - PB;

const chartPoints = computed(() => {
  const recs = sortedRecords.value;
  if (recs.length === 0) return [];
  const weights = recs.map(r => r.weight);
  // 目标体重也纳入 Y 轴范围，保证目标线可见
  const target = store.user?.targetWeight;
  if (target) weights.push(target);
  const minW = Math.min(...weights);
  const maxW = Math.max(...weights);
  const range = maxW - minW || 1;
  const pad = range * 0.2;
  const yMin = minW - pad;
  const yMax = maxW + pad;

  return recs.map((r, i) => {
    const x = recs.length === 1
      ? PL + PW / 2
      : PL + (i / (recs.length - 1)) * PW;
    const y = PT + PH - ((r.weight - yMin) / (yMax - yMin)) * PH;
    return { x, y, weight: r.weight, label: format(new Date(r.date.replace(' ', 'T')), 'M/d') };
  });
});

// 目标体重线的 Y 坐标
const targetLineY = computed(() => {
  const target = store.user?.targetWeight;
  if (!target) return null;
  const recs = sortedRecords.value;
  if (recs.length === 0) return null;
  const weights = recs.map(r => r.weight);
  weights.push(target);
  const minW = Math.min(...weights);
  const maxW = Math.max(...weights);
  const range = maxW - minW || 1;
  const pad = range * 0.2;
  const yMin = minW - pad;
  const yMax = maxW + pad;
  return PT + PH - ((target - yMin) / (yMax - yMin)) * PH;
});

const linePath = computed(() =>
  chartPoints.value.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ')
);

const areaPath = computed(() => {
  const pts = chartPoints.value;
  if (pts.length === 0) return '';
  const baseY = PT + PH;
  return `M ${pts[0].x.toFixed(1)} ${baseY} ` +
    pts.map(p => `L ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ') +
    ` L ${pts[pts.length - 1].x.toFixed(1)} ${baseY} Z`;
});

const yLabels = computed(() => {
  const recs = sortedRecords.value;
  if (recs.length === 0) return [];
  const weights = recs.map(r => r.weight);
  const minW = Math.min(...weights);
  const maxW = Math.max(...weights);
  const range = maxW - minW || 1;
  const pad = range * 0.2;
  const yMin = minW - pad;
  const yMax = maxW + pad;
  return Array.from({ length: 4 }, (_, i) => {
    const val = yMin + (i / 3) * (yMax - yMin);
    const y = PT + PH - (i / 3) * PH;
    return { value: val.toFixed(1), y };
  });
});

const xLabels = computed(() => {
  const pts = chartPoints.value;
  if (pts.length === 0) return [];
  const step = Math.ceil(pts.length / 6);
  const labels: { x: number; label: string }[] = [];
  for (let i = 0; i < pts.length; i += step) {
    labels.push({ x: pts[i].x, label: pts[i].label });
  }
  const last = pts[pts.length - 1];
  if (labels.length > 0 && labels[labels.length - 1].x !== last.x) {
    labels.push({ x: last.x, label: last.label });
  }
  return labels;
});

const selectedIdx = ref<number | null>(null);
const hoveredIdx = ref<number | null>(null);
const activeIdx = computed(() => selectedIdx.value ?? hoveredIdx.value);

// 选中的数据点详情
const selectedPoint = computed(() => {
  const idx = activeIdx.value;
  if (idx === null || !chartPoints.value[idx]) return null;
  const pt = chartPoints.value[idx];
  const recs = sortedRecords.value;
  const rec = recs[idx];
  const prevWeight = idx > 0 ? recs[idx - 1].weight : null;
  const change = prevWeight !== null ? parseFloat((pt.weight - prevWeight).toFixed(1)) : null;
  return {
    ...pt,
    fullDate: rec ? format(new Date(rec.date.replace(' ', 'T')), 'MM月dd日 HH:mm') : '',
    change,
    prevWeight,
  };
});

// 将客户端坐标转换为 SVG 坐标系下的 x
function clientToSvgX(clientX: number, svgEl: SVGSVGElement): number {
  const rect = svgEl.getBoundingClientRect();
  return ((clientX - rect.left) / rect.width) * CW;
}

// 找到最近的点的索引
function findNearestPoint(svgX: number): number | null {
  const pts = chartPoints.value;
  if (pts.length === 0) return null;
  let minDist = Infinity;
  let nearest = 0;
  for (let i = 0; i < pts.length; i++) {
    const d = Math.abs(pts[i].x - svgX);
    if (d < minDist) { minDist = d; nearest = i; }
  }
  return nearest;
}

// 点击/触摸图表区域 -> 选中最近的数据点
function handleChartClick(e: MouseEvent) {
  const svg = e.currentTarget as SVGSVGElement;
  const idx = findNearestPoint(clientToSvgX(e.clientX, svg));
  if (idx !== null) selectedIdx.value = idx;
}

function handleChartTouchStart(e: TouchEvent) {
  e.preventDefault();
  const svg = e.currentTarget as SVGSVGElement;
  if (e.touches.length > 0) {
    const idx = findNearestPoint(clientToSvgX(e.touches[0].clientX, svg));
    if (idx !== null) selectedIdx.value = idx;
  }
}

function handleChartTouchMove(e: TouchEvent) {
  e.preventDefault();
  const svg = e.currentTarget as SVGSVGElement;
  if (e.touches.length > 0) {
    const idx = findNearestPoint(clientToSvgX(e.touches[0].clientX, svg));
    if (idx !== null) selectedIdx.value = idx;
  }
}

onMounted(() => {
  // 打开页面时把未读批注标记为已读
  store.weightRecords.forEach((r) => {
    if ((r.studentId === store.user?.id || !r.studentId) && r.dietitianComment && !r.commentRead) {
      store.updateWeightRecord(r.id, { commentRead: true });
    }
  });
});
</script>

<template>
  <div class="flex min-h-full flex-col bg-[#F7F8FA] pb-safe">
    <NavBar title="体重打卡" :on-back="store.goBack" />

    <div class="p-6 space-y-6">
      <div class="flex flex-col items-center justify-center space-y-4 py-8 animate-pop-in">
        <div class="w-20 h-20 rounded-full bg-[#1677FF]/10 flex items-center justify-center text-[#1677FF] animate-pulse">
          <Scale class="h-10 w-10" />
        </div>
        <h2 class="text-xl font-bold text-gray-900">今日体重</h2>
        <p class="text-sm text-gray-500 text-center">记录每日体重变化，生成专属趋势图表</p>
      </div>

      <Card class="p-6 transition-transform hover:scale-[1.01]">
        <div class="flex items-center justify-center space-x-2 border-b border-gray-200 pb-4">
          <input
            type="number"
            step="0.1"
            :value="weight"
            @input="weight = ($event.target as HTMLInputElement).value; error = ''"
            class="text-5xl font-light text-center text-gray-900 focus:outline-none w-40 bg-transparent"
            placeholder="0.0"
            v-focus
          />
          <span class="text-xl font-medium text-gray-400 pb-1">kg</span>
        </div>
        <div v-if="error" class="text-red-500 text-sm text-center mt-4 animate-shake">{{ error }}</div>
      </Card>

      <!-- Photo upload (折叠) -->
      <Card class="p-4 space-y-3">
        <button @click="showPhotoUpload = !showPhotoUpload" class="w-full flex items-center justify-between">
          <span class="text-sm font-bold text-gray-700 flex items-center gap-1.5">
            <Camera class="w-4 h-4 text-gray-400" />
            打卡照片 <span class="text-[10px] text-gray-400 font-normal">(选填)</span>
          </span>
          <span class="text-xs text-[#1677FF] font-medium">{{ showPhotoUpload ? '收起' : photos.length > 0 ? `已选 ${photos.length} 张` : '添加' }}</span>
        </button>
        <div v-show="showPhotoUpload">
          <input ref="photoInputRef" type="file" accept="image/*" multiple class="hidden" @change="handlePhotoSelect" />
          <div class="grid grid-cols-3 gap-2">
            <div v-for="(url, idx) in photos" :key="idx" class="aspect-square rounded-xl bg-gray-100 overflow-hidden relative animate-pop-in">
              <img :src="url" alt="体重打卡" class="w-full min-h-full object-cover" />
              <button
                @click="removePhoto(idx)"
                class="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1"
              >
                <X class="w-3 h-3" />
              </button>
            </div>
            <div
              v-if="photos.length < 6"
              @click="photoInputRef?.click()"
              class="aspect-square rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors active:scale-95"
            >
              <Camera class="h-6 w-6 text-gray-400 mb-1" />
              <span class="text-[10px] text-gray-400">添加图片</span>
            </div>
          </div>
        </div>
      </Card>

      <!-- 目标体重 -->
      <Card class="p-4">
        <div class="flex items-center justify-between">
          <span class="text-sm font-bold text-gray-700 flex items-center gap-1.5">
            <Target class="w-4 h-4 text-[#FF976A]" />
            我的目标体重
          </span>
          <button v-if="!editingTarget" @click="editingTarget = true" class="text-xs text-[#1677FF] font-medium flex items-center gap-1">
            <Pencil class="w-3 h-3" /> {{ store.user?.targetWeight ? '修改' : '设置' }}
          </button>
        </div>
        <div v-if="editingTarget" class="flex items-center gap-2 mt-3">
          <input
            type="number"
            step="0.1"
            v-model="targetWeight"
            placeholder="例如 60.0"
            class="flex-1 rounded-lg border border-gray-200 p-2.5 text-sm focus:border-[#1677FF] focus:outline-none"
          />
          <span class="text-sm text-gray-400">kg</span>
          <button @click="saveTarget" class="px-4 py-2.5 bg-[#1677FF] text-white text-sm font-bold rounded-lg active:scale-95 transition-transform">保存</button>
        </div>
        <div v-else class="mt-2">
          <div v-if="store.user?.targetWeight" class="flex items-baseline gap-2">
            <span class="text-2xl font-black text-[#FF976A]">{{ store.user.targetWeight }}</span>
            <span class="text-xs text-gray-400">kg</span>
            <span v-if="weightStats" class="text-xs text-gray-500 ml-1">还差 {{ Math.abs(parseFloat((weightStats.last - store.user.targetWeight).toFixed(1))) }} kg</span>
          </div>
          <div v-else class="text-xs text-gray-400">设置一个目标，趋势图会显示目标线，更有动力</div>
        </div>
      </Card>

      <div class="pt-2">
        <Button class="w-full bg-[#1677FF] hover:bg-[#1677FF]/90 text-white shadow-lg shadow-[#1677FF]/20 active:scale-95 transition-transform" size="lg" @click="handleSubmit">
          完成打卡
        </Button>
      </div>

      <!-- Weight trend chart -->
      <div v-if="sortedRecords.length >= 2" class="space-y-3 pt-2">
        <div class="flex items-center justify-between px-1">
          <h3 class="text-sm font-bold text-gray-900">体重趋势</h3>
          <div v-if="weightStats" class="flex items-center gap-1.5">
            <span class="text-[11px] text-gray-400">{{ weightStats.first }} → {{ weightStats.last }}kg</span>
            <span :class="[
              'text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5',
              weightStats.change < 0 ? 'text-[#07C160] bg-green-50' :
              weightStats.change > 0 ? 'text-orange-500 bg-orange-50' : 'text-gray-400 bg-gray-50'
            ]">
              <TrendingDown v-if="weightStats.change < 0" class="w-3 h-3" />
              <TrendingUp v-else-if="weightStats.change > 0" class="w-3 h-3" />
              <Minus v-else class="w-3 h-3" />
              {{ weightStats.change > 0 ? '+' : '' }}{{ weightStats.change }}kg
            </span>
          </div>
        </div>

        <Card class="p-4">
          <svg :viewBox="`0 0 ${CW} ${CH}`" class="w-full touch-none select-none"
               preserveAspectRatio="xMidYMid meet"
               @click="handleChartClick"
               @touchstart="handleChartTouchStart"
               @touchmove="handleChartTouchMove">
            <defs>
              <linearGradient id="weightGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#1677FF" stop-opacity="0.15" />
                <stop offset="100%" stop-color="#1677FF" stop-opacity="0" />
              </linearGradient>
              <filter id="pointGlow">
                <feGaussianBlur stdDeviation="2" result="blur"/>
                <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
            </defs>

            <!-- Grid lines -->
            <line v-for="(lb, i) in yLabels" :key="`g-${i}`"
                  :x1="PL" :y1="lb.y" :x2="CW - PR" :y2="lb.y"
                  stroke="#f0f0f0" stroke-width="1" />
            <!-- Y labels -->
            <text v-for="(lb, i) in yLabels" :key="`yl-${i}`"
                  :x="PL - 5" :y="lb.y + 3" text-anchor="end"
                  font-size="9" fill="#9ca3af">{{ lb.value }}</text>

            <!-- Area -->
            <path :d="areaPath" fill="url(#weightGrad)" />

            <!-- Line -->
            <path :d="linePath" fill="none" stroke="#1677FF" stroke-width="2"
                  stroke-linejoin="round" stroke-linecap="round" />

            <!-- 目标体重线 -->
            <g v-if="targetLineY !== null">
              <line :x1="PL" :y1="targetLineY" :x2="CW - PR" :y2="targetLineY"
                    stroke="#FF976A" stroke-width="1.5" stroke-dasharray="5 4" opacity="0.8" />
              <text :x="CW - PR" :y="targetLineY - 4" text-anchor="end"
                    font-size="9" fill="#FF976A" font-weight="bold">目标 {{ store.user?.targetWeight }}kg</text>
            </g>

            <!-- Vertical guide line (active point) -->
            <line v-if="activeIdx !== null && chartPoints[activeIdx]"
                  :x1="chartPoints[activeIdx].x" :y1="PT"
                  :x2="chartPoints[activeIdx].x" :y2="PT + PH"
                  stroke="#1677FF" stroke-width="1" stroke-dasharray="3 3" opacity="0.4" />

            <!-- Points -->
            <circle v-for="(pt, i) in chartPoints" :key="`p-${i}`"
                    :cx="pt.x" :cy="pt.y"
                    :r="activeIdx === i ? 5.5 : 3.5"
                    :fill="activeIdx === i ? '#1677FF' : '#fff'"
                    :filter="activeIdx === i ? 'url(#pointGlow)' : ''"
                    stroke="#1677FF" stroke-width="2"
                    class="cursor-pointer transition-all"
                    @mouseenter="hoveredIdx = i"
                    @mouseleave="hoveredIdx = null" />

            <!-- X labels -->
            <text v-for="(lb, i) in xLabels" :key="`xl-${i}`"
                  :x="lb.x" :y="CH - 8" text-anchor="middle"
                  font-size="9" fill="#9ca3af">{{ lb.label }}</text>

            <!-- Enhanced tooltip with date + weight -->
            <g v-if="activeIdx !== null && chartPoints[activeIdx]">
              <!-- Tooltip card -->
              <rect :x="Math.max(PL, Math.min(CW - PR - 72, chartPoints[activeIdx].x - 36))"
                    :y="chartPoints[activeIdx].y - 38" width="72" height="28" rx="5"
                    fill="#1e293b" />
              <text :x="Math.max(PL + 36, Math.min(CW - PR - 36, chartPoints[activeIdx].x))"
                    :y="chartPoints[activeIdx].y - 24" text-anchor="middle"
                    font-size="11" fill="#fff" font-weight="bold">
                {{ chartPoints[activeIdx].weight }}kg
              </text>
              <text :x="Math.max(PL + 36, Math.min(CW - PR - 36, chartPoints[activeIdx].x))"
                    :y="chartPoints[activeIdx].y - 14" text-anchor="middle"
                    font-size="8" fill="rgba(255,255,255,0.7)">
                {{ chartPoints[activeIdx].label }}
              </text>
            </g>
          </svg>

          <!-- Selected point detail card -->
          <div v-if="selectedPoint" class="mt-3 p-3 rounded-xl bg-[#1677FF]/5 border border-[#1677FF]/10 flex items-center justify-between">
            <div>
              <div class="text-[10px] text-gray-500 mb-0.5">打卡时间</div>
              <div class="text-xs font-medium text-gray-700">{{ selectedPoint.fullDate }}</div>
            </div>
            <div class="text-right">
              <div class="text-[10px] text-gray-500 mb-0.5">体重</div>
              <div class="text-sm font-bold text-[#1677FF]">{{ selectedPoint.weight }} kg</div>
            </div>
            <div v-if="selectedPoint.change !== null" class="text-right">
              <div class="text-[10px] text-gray-500 mb-0.5">较上次</div>
              <div :class="['text-sm font-bold', selectedPoint.change < 0 ? 'text-[#07C160]' : selectedPoint.change > 0 ? 'text-orange-500' : 'text-gray-500']">
                {{ selectedPoint.change > 0 ? '+' : '' }}{{ selectedPoint.change }} kg
              </div>
            </div>
          </div>

          <!-- Hint text -->
          <p v-if="!selectedPoint" class="text-center text-[10px] text-gray-400 mt-2">点击曲线上的点查看详细数据</p>

          <!-- Stats -->
          <div v-if="weightStats" class="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-gray-100">
            <div class="text-center">
              <div class="text-[10px] text-gray-400 mb-0.5">最高</div>
              <div class="text-sm font-bold text-gray-700">{{ weightStats.max }}kg</div>
            </div>
            <div class="text-center">
              <div class="text-[10px] text-gray-400 mb-0.5">最低</div>
              <div class="text-sm font-bold text-gray-700">{{ weightStats.min }}kg</div>
            </div>
            <div class="text-center">
              <div class="text-[10px] text-gray-400 mb-0.5">记录</div>
              <div class="text-sm font-bold text-gray-700">{{ weightStats.count }}次</div>
            </div>
          </div>
        </Card>
      </div>

      <!-- Only 1 record -->
      <div v-else-if="sortedRecords.length === 1" class="text-center py-6 bg-white rounded-2xl border border-gray-100">
        <div class="w-14 h-14 mx-auto mb-2 rounded-full bg-[#1677FF]/10 flex items-center justify-center">
          <TrendingUp class="w-7 h-7 text-[#1677FF]" />
        </div>
        <div class="text-sm font-bold text-gray-700">已记录 1 次体重</div>
        <div class="text-xs text-gray-400 mt-0.5">再打卡 1 次即可生成你的专属趋势图</div>
      </div>

      <!-- 打卡记录列表（按日期分组，含营养师批注） -->
      <div v-if="sortedRecords.length > 0" class="space-y-3 pt-2">
        <h3 class="text-sm font-bold text-gray-900 px-1">打卡记录</h3><div v-for="group in groupedHistory" :key="group.date">
          <!-- Date header -->
          <button
            @click="toggleDate(group.date)"
            class="w-full flex items-center justify-between bg-white rounded-xl px-4 py-2.5 mb-2 border border-gray-100 sticky top-0 z-10 shadow-sm"
          >
            <div class="flex items-center gap-2">
              <span class="w-1 h-4 rounded-full bg-[#1677FF]"></span>
              <span class="text-sm font-bold text-gray-800">{{ group.label }}</span>
              <span class="text-[10px] text-gray-400">{{ group.records.length }}条记录</span>
            </div>
            <ChevronDown
              class="w-4 h-4 text-gray-400 transition-transform duration-200"
              :class="{ 'rotate-180': isExpanded(group.date) }"
            />
          </button>
          <!-- Records for this date -->
          <div v-show="isExpanded(group.date)" class="animate-pop-in">
            <Card class="p-0 overflow-hidden">
              <div class="divide-y divide-gray-50">
                <div
                  v-for="w in group.records"
                  :key="w.id"
                  class="px-4 py-3"
                >
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-[#1677FF]/10 flex items-center justify-center text-[#1677FF]">
                        <Scale class="w-4 h-4" />
                      </div>
                      <div>
                        <div class="text-sm font-medium text-gray-900">{{ formatDateTime(w.date) }}</div>
                        <div class="text-[10px] text-gray-400">体重打卡</div>
                      </div>
                    </div>
                    <div class="text-lg font-bold text-gray-900">{{ w.weight }}<span class="text-xs font-normal text-gray-400 ml-0.5">kg</span></div>
                  </div>
                  <!-- 打卡照片 -->
                  <div v-if="w.photos && w.photos.length > 0" class="mt-2 ml-11 flex gap-2 overflow-x-auto pb-1 snap-x snap-mandatory [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                    <img
                      v-for="(url, idx) in w.photos"
                      :key="idx"
                      :src="url"
                      alt="体重打卡"
                      class="h-16 w-16 object-cover rounded-lg shrink-0 snap-center border border-gray-100 cursor-pointer"
                      @click="store.openImagePreview(w.photos || [], idx)"
                    />
                  </div>
                  <!-- 批注 -->
                  <div v-if="w.dietitianComment" class="mt-2 ml-11 bg-[#1677FF]/5 rounded-lg p-3 border border-[#1677FF]/10">
                    <div class="flex items-center justify-between mb-1">
                      <span class="text-xs font-bold text-[#1677FF] flex items-center gap-1.5">
                        批注
                        <span v-if="!w.commentRead" class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      </span>
                      <span v-if="w.dietitianCommentDate" class="text-[10px] text-gray-400">{{ w.dietitianCommentDate }}</span>
                    </div>
                    <p class="text-sm text-gray-700 whitespace-pre-wrap">{{ w.dietitianComment }}</p>
                    <!-- 学员反馈 -->
                    <div class="flex gap-2 mt-2">
                      <button
                        @click="markWeightFeedback(w.id, 'received')"
                        :class="['text-[10px] px-2.5 py-1 rounded-full font-bold transition-all active:scale-95', w.studentFeedback === 'received' ? 'bg-[#07C160] text-white' : 'bg-white text-gray-500 border border-gray-200']"
                      >
                        {{ w.studentFeedback === 'received' ? '✓ 已收到' : '收到' }}
                      </button>
                      <button
                        @click="markWeightFeedback(w.id, 'helpful')"
                        :class="['text-[10px] px-2.5 py-1 rounded-full font-bold transition-all active:scale-95', w.studentFeedback === 'helpful' ? 'bg-[#FF976A] text-white' : 'bg-white text-gray-500 border border-gray-200']"
                      >
                        {{ w.studentFeedback === 'helpful' ? '✓ 有用' : '👍 有用' }}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@keyframes popIn {
  0% { transform: scale(0.9); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  20%, 60% { transform: translateX(-4px); }
  40%, 80% { transform: translateX(4px); }
}
.animate-pop-in {
  animation: popIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}
.animate-shake {
  animation: shake 0.4s ease-in-out;
}
</style>
