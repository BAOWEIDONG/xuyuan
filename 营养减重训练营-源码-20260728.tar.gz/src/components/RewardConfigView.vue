<script setup lang="ts">
import { ref, computed } from 'vue';
import { useAppStore } from '../store/app';
import { NavBar, Card, Button } from './ui';
import { Popup as VanPopup, showToast } from 'vant';
import { Plus, Trash2, Edit3, Camera, AlertTriangle } from 'lucide-vue-next';
import { uploadFile } from '../lib/api';
import type { RewardTier } from '../types';

const store = useAppStore();
const showEditModal = ref(false);
const editingTier = ref<Partial<RewardTier> | null>(null);
const formError = ref('');
const photoInputRef = ref<HTMLInputElement | null>(null);

// 统计每个奖励阶梯的领取数量
const getClaimCount = (tierId: string) => store.rewardClaims.filter(c => c.tierId === tierId).length;

const handleEdit = (tier?: RewardTier) => {
  editingTier.value = tier ? { ...tier } : { name: '', requiredDays: 1, imageUrl: '', stock: 10 };
  formError.value = '';
  showEditModal.value = true;
};

const handlePhotoSelect = async (e: Event) => {
  const files = (e.target as HTMLInputElement).files;
  if (!files || files.length === 0) return;
  const url = await uploadFile(files[0]);
  if (editingTier.value) editingTier.value.imageUrl = url;
  (e.target as HTMLInputElement).value = '';
};

const handleDelete = (id: string) => {
  const claimCount = getClaimCount(id);
  if (claimCount > 0) {
    showToast(`该奖励已有 ${claimCount} 名学员领取，无法删除`);
    return;
  }
  if (confirm('确定删除此奖励阶梯？')) store.deleteRewardTier(id);
};

const saveTier = () => {
  if (!editingTier.value) return;
  if (!editingTier.value.name?.trim()) { formError.value = '请输入礼品名称'; return; }
  if (!editingTier.value.requiredDays || editingTier.value.requiredDays <= 0) { formError.value = '请输入有效的天数'; return; }
  if (!editingTier.value.imageUrl) { formError.value = '请上传礼品图片'; return; }
  if (editingTier.value.stock === undefined || editingTier.value.stock < 0) { formError.value = '请输入有效的库存'; return; }

  // 检查天数是否与其他阶梯冲突
  const dup = store.rewardTiers.find(t => t.requiredDays === editingTier.value!.requiredDays && t.id !== editingTier.value!.id);
  if (dup) { formError.value = `已存在连续打卡 ${editingTier.value.requiredDays} 天的奖励（${dup.name}），请设置不同天数`; return; }

  if (editingTier.value.id) {
    store.updateRewardTier(editingTier.value.id, editingTier.value);
  } else {
    store.addRewardTier({ id: `t_${Date.now()}`, name: editingTier.value.name.trim(), requiredDays: editingTier.value.requiredDays, imageUrl: editingTier.value.imageUrl, stock: editingTier.value.stock });
  }
  showEditModal.value = false;
};

const sortedTiers = computed(() => [...store.rewardTiers].sort((a, b) => a.requiredDays - b.requiredDays));
</script>

<template>
  <div class="flex min-h-full flex-col bg-[#F7F8FA] relative">
    <NavBar title="奖励配置" :on-back="store.goBack" />

    <div class="flex-1 p-4 space-y-4 pb-24">
      <div v-if="sortedTiers.length === 0" class="text-center py-20 text-gray-400 text-sm">暂无奖励配置，请添加</div>
      <Card v-for="tier in sortedTiers" :key="tier.id" class="p-4 flex gap-4">
        <div class="w-20 h-20 rounded-xl bg-gray-100 shrink-0 overflow-hidden border border-gray-50 cursor-pointer" @click="store.openImagePreview([tier.imageUrl], 0)">
          <img :src="tier.imageUrl" :alt="tier.name" class="w-full h-full object-cover" />
        </div>
        <div class="flex-1 flex flex-col justify-between min-w-0">
          <div>
            <div class="flex justify-between items-start">
              <h3 class="font-bold text-gray-900 text-base truncate pr-2">{{ tier.name }}</h3>
              <div class="flex gap-2 shrink-0">
                <button @click="handleEdit(tier)" class="text-blue-500 p-1"><Edit3 class="w-4 h-4" /></button>
                <button @click="handleDelete(tier.id)" :class="['p-1', getClaimCount(tier.id) > 0 ? 'text-gray-300 cursor-not-allowed' : 'text-red-500']"><Trash2 class="w-4 h-4" /></button>
              </div>
            </div>
            <div class="text-xs text-orange-600 bg-orange-50 px-2 py-0.5 rounded inline-block mt-1">连续打卡 {{ tier.requiredDays }} 天</div>
            <div v-if="getClaimCount(tier.id) > 0" class="text-[10px] text-gray-500 mt-1">已有 {{ getClaimCount(tier.id) }} 人领取</div>
          </div>
          <div class="text-xs text-gray-500 font-medium">库存: <span :class="tier.stock > 0 ? 'text-gray-900' : 'text-red-500'">{{ tier.stock }}</span> 件</div>
        </div>
      </Card>
    </div>

    <div class="sticky bottom-0 p-4 bg-white border-t border-gray-100">
      <button class="w-full py-3 rounded-xl bg-[#1677FF] text-white font-bold flex items-center justify-center gap-1" @click="handleEdit()">
        <Plus class="w-5 h-5" /> 新增奖励阶梯
      </button>
    </div>

    <!-- Edit popup -->
    <VanPopup v-model:show="showEditModal" position="bottom" round :style="{ maxHeight: '90%' }">
      <div class="p-5" v-if="editingTier">
        <h3 class="text-lg font-bold text-gray-900 mb-5">{{ editingTier.id ? '编辑奖励阶梯' : '新增奖励阶梯' }}</h3>
        <!-- 已有领取记录警告 -->
        <div v-if="editingTier.id && getClaimCount(editingTier.id) > 0" class="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
          <AlertTriangle class="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
          <div class="text-xs text-amber-700">
            <div class="font-bold mb-0.5">该奖励已有 {{ getClaimCount(editingTier.id) }} 人领取</div>
            <div>修改解锁天数会影响学员的进度计算，请谨慎操作。礼品名称和库存可安全修改。</div>
          </div>
        </div>
        <div class="space-y-4 mb-6">
          <div>
            <label class="text-sm font-medium text-gray-700 block mb-2">礼品图片 <span class="text-red-500">*</span></label>
            <input ref="photoInputRef" type="file" accept="image/*" class="hidden" @change="handlePhotoSelect" />
            <div class="w-24 h-24 rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 overflow-hidden" @click="photoInputRef?.click()">
              <img v-if="editingTier.imageUrl" :src="editingTier.imageUrl" class="w-full h-full object-cover" />
              <template v-else><Camera class="w-6 h-6 text-gray-400 mb-1" /><span class="text-[10px] text-gray-400">上传图片</span></template>
            </div>
          </div>
          <div>
            <label class="text-sm font-medium text-gray-700 block mb-1">礼品名称 <span class="text-red-500">*</span></label>
            <input type="text" placeholder="如：运动水杯" class="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#1677FF] text-sm" v-model="editingTier.name" @input="formError = ''" />
          </div>
          <div>
            <label class="text-sm font-medium text-gray-700 block mb-1">解锁条件 (连续打卡天数) <span class="text-red-500">*</span></label>
            <input type="number" placeholder="如：10" min="1" class="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#1677FF] text-sm" :value="editingTier.requiredDays" @input="editingTier.requiredDays = parseInt(($event.target as HTMLInputElement).value) || 0; formError = ''" />
          </div>
          <div>
            <label class="text-sm font-medium text-gray-700 block mb-1">库存数量 <span class="text-red-500">*</span></label>
            <input type="number" placeholder="如：50" min="0" class="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#1677FF] text-sm" :value="editingTier.stock" @input="editingTier.stock = parseInt(($event.target as HTMLInputElement).value) || 0; formError = ''" />
          </div>
          <div v-if="formError" class="text-red-500 text-xs font-medium text-center">{{ formError }}</div>
        </div>
        <button class="w-full py-3 rounded-xl bg-[#1677FF] text-white font-bold" @click="saveTier">保存配置</button>
      </div>
    </VanPopup>
  </div>
</template>
